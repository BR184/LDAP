package com.company.idm.domain.department;

import com.company.idm.common.enums.SourceType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * 部门领域实体，描述组织节点的基础属性。
 */
@Getter
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class Department {

    private Long id;
    private String deptCode;
    private String deptName;
    private String parentDeptCode;
    private String ancestorPath;
    private Integer deptLevel;
    private SourceType sourceType;
    private String externalId;
    private String ldapDn;
    private Integer status;
}


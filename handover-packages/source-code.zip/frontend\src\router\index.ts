import { createRouter, createWebHistory, type RouteRecordRaw } from 'vue-router'
import AdminLayout from '@/layout/AdminLayout.vue'
import pinia from '@/stores'
import { useAuthStore } from '@/stores/auth'
import { useMenuStore } from '@/stores/menu'

const routes: RouteRecordRaw[] = [
  {
    path: '/login',
    name: 'login',
    component: () => import('@/views/auth/LoginView.vue'),
    meta: {
      title: '登录',
      requiresAuth: false,
    },
  },
  {
    path: '/',
    component: AdminLayout,
    redirect: '/dashboard',
    children: [
      {
        path: 'dashboard',
        name: 'dashboard',
        component: () => import('@/views/dashboard/DashboardView.vue'),
        meta: { title: '首页' },
      },
      {
        path: 'users',
        name: 'users',
        component: () => import('@/views/user/UserListView.vue'),
        meta: { title: '用户管理' },
      },
      {
        path: 'departments',
        name: 'departments',
        component: () => import('@/views/department/DepartmentTreeView.vue'),
        meta: { title: '部门管理' },
      },
      {
        path: 'roles',
        name: 'roles',
        component: () => import('@/views/role/RoleListView.vue'),
        meta: { title: '角色管理' },
      },
      {
        path: 'menus',
        name: 'menus',
        component: () => import('@/views/menu/MenuTreeView.vue'),
        meta: { title: '菜单管理' },
      },
      {
        path: 'ldap',
        name: 'ldap',
        component: () => import('@/views/ldap/LdapControlView.vue'),
        meta: { title: 'LDAP 控制面' },
      },
      {
        path: 'system/mail-config',
        name: 'system-mail-config',
        component: () => import('@/views/system/SystemMailConfigView.vue'),
        meta: { title: '邮件配置' },
      },
      {
        path: 'system/imports',
        name: 'system-imports',
        component: () => import('@/views/system/SystemImportView.vue'),
        meta: { title: '文件导入' },
      },
      {
        path: 'sync/jobs',
        name: 'sync-jobs',
        component: () => import('@/views/sync/SyncJobListView.vue'),
        meta: { title: '同步任务' },
      },
      {
        path: 'profile',
        name: 'profile',
        component: () => import('@/views/profile/ProfileView.vue'),
        meta: { title: '个人中心', hideInMenu: true },
      },
    ],
  },
  {
    path: '/:pathMatch(.*)*',
    name: 'not-found',
    component: () => import('@/views/system/NotFoundView.vue'),
    meta: {
      title: '页面不存在',
      requiresAuth: false,
    },
  },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior() {
    return { top: 0 }
  },
})

router.beforeEach(async (to) => {
  const authStore = useAuthStore(pinia)
  const menuStore = useMenuStore(pinia)
  const requiresAuth = to.meta.requiresAuth !== false

  if (!requiresAuth) {
    if (to.path === '/login' && authStore.token) {
      return '/dashboard'
    }

    return true
  }

  if (!authStore.token) {
    return {
      path: '/login',
      query: {
        redirect: to.fullPath,
      },
    }
  }

  if (!authStore.profileLoaded) {
    try {
      await authStore.loadProfile()
    } catch {
      return {
        path: '/login',
        query: {
          redirect: to.fullPath,
        },
      }
    }
  }

  if (!menuStore.loaded) {
    try {
      await menuStore.loadMenus()
    } catch {
      authStore.clearSession()
      return {
        path: '/login',
        query: {
          redirect: to.fullPath,
        },
      }
    }
  }

  if (!menuStore.canAccess(to.path)) {
    return '/dashboard'
  }

  return true
})

export default router
